<!DOCTYPE html>
<html>
<head>
<title>Yet Another webpage</title>
</head>
<body>

<h1>Webpage</h1>
<p>We are use versionning</p>
<?php
$loggedin = false;
if(array_key_exists("password",$_GET)){
    $hash = md5($_GET['password']);

    if ($hash == trim(file_get_contents("./p4sSw0rd_sUp34_H1dD3n.md5"))){
        $loggedin = true;
?>
<p>You are authorized to see this page</p
<p>Here is the content of the file : <?=file_get_contents("/flag/flag");?></p>
<?php
    }

}
if (! $loggedin){
?>

<p>You are not autorized to see the content of this page</p>
<p>Please log in </p>
<form action=".">
Enter your password :
<input type="text" name="password"></input>
<input type="submit">
</form>
<?php
}
?>


</body>
</html>

